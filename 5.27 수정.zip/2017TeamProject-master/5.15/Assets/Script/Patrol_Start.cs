﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//경찰 2-3명 배치 시 사용
public class Patrol_Start : MonoBehaviour {
    private Transform[] Police_Point;
    public GameObject PolicePrefab;

    // Use this for initialization
    void Start()
    {
        StartCoroutine(this.PoliceOn());
    }
    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator PoliceOn()
    {
        while (true)
        {
            yield return new WaitForSeconds(1.0f);
            int idx = Random.Range(0, 2);
            Instantiate(PolicePrefab, Police_Point[idx].position, Police_Point[idx].rotation);

        }
    }
}
