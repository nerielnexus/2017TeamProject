﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gift_icon_setactive : MonoBehaviour {
    private GameObject HouseBool;
    public bool exist;  //icon이 존재하냐?

    // Use this for initialization
    void Start () {
        HouseBool = transform.parent.gameObject;
        
    }
	
	// Update is called once per frame
	void Update () {
        
        if (HouseBool.GetComponent<HouseFail>().success)
        {
            this.gameObject.SetActive(false);
            exist = false;
        }
        if (HouseBool.GetComponent<HouseFail>().fail)
        {
            this.gameObject.SetActive(false);
            exist = false;
        }
    }
}
