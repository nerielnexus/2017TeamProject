﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStart : MonoBehaviour {
    private Transform point;
    public GameObject EnemyPrefab;
    public bool CheckGauge;
    private GameObject HouseBool;
    // Use this for initialization
    void Start()
    {
        point = this.gameObject.transform;
        HouseBool = transform.parent.gameObject;
        StartCoroutine(this.EnemyOn());
    }
	// Update is called once per frame
	void Update () {

	}

    IEnumerator EnemyOn()
    {
        while (true)
        {
            yield return new WaitForSeconds(0.2f);
            if (HouseBool.GetComponent<HouseFail>().fail)
            {
                Instantiate(EnemyPrefab, point.position, point.rotation);
                HouseBool.GetComponent<HouseFail>().fail = false;
            }
           
        }
    }
}
