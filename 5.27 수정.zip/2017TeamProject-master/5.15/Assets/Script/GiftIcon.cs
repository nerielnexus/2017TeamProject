﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//선물 줄 집 랜덤하게 설정한다.
public class GiftIcon : MonoBehaviour {

    //선물 줄 집의 오브젝트를 담을 배열
    public GameObject[] Gifts;

    //Enemy를 발생시킬 시간
    public float createTime = 2.0f;

    //최대 몇 개?
    public int maxGift = 10;

    // Use this for initialization
    void Start() {
   
        StartCoroutine(this.CreateGift());
    }
    
    IEnumerator CreateGift()
    {
        while (true)
        {
            int GiftCount = (int)GameObject.FindGameObjectsWithTag("House").Length;
            
                //createTime만큼 기다려라
                yield return new WaitForSeconds(createTime);

                //랜덤하게
                int idx = Random.Range(0, GiftCount);

                Gifts[idx].SetActive(true);
                Gifts[idx].GetComponent<Gift_icon_setactive>().exist = true;
           
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
