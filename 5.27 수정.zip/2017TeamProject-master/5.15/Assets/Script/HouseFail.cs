﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HouseFail : MonoBehaviour {
    //게이지 실패용 실험판 나중에 지울 것
    private Transform playerTr;
    private Transform houseTr;
    public float dist;
    public bool fail;
    public bool success;

    public GameObject Gift_UI;

	// Use this for initialization
	void Start () {
        playerTr = GameObject.FindWithTag("Player").GetComponent<Transform>();
        houseTr = this.gameObject.transform;
                
        StartCoroutine(this.CheckFail());
        Gift_UI = transform.Find("Gift_UI").gameObject;
    }
	
	// Update is called once per frame
	void Update () {
        
    }

    IEnumerator CheckFail()
    {
        while (true)
        {
            yield return new WaitForSeconds(0.05f);
            dist = Vector3.Distance(playerTr.position, houseTr.position);

            if (Gift_UI.GetComponent<Gift_icon_setactive>().exist == true)
            {
                //1번 누르면 실패
                if (dist <= 13.0f && Input.GetKey(KeyCode.Alpha1))
                {
                    fail = true;
                }
                //2번 누르면 성공
                else if (dist <= 13.0f && Input.GetKey(KeyCode.Alpha2))
                {
                    success = true;
                }
                else
                {
                    success = false;
                    fail = false;
                }

            }
            
        }
    }
}
